// ignore_for_file: avoid_print
// import 'dart:convert';
// import 'package:flutter/services.dart';
import 'dart:convert' as convert;
import 'dart:ui' as ui show window;
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  runApp(MyApp());
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  late WebViewController _controller;

  MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    double statusBarHeight = 0.0;
    MediaQueryData mediaQuery = MediaQueryData.fromWindow(ui.window);
    statusBarHeight = mediaQuery.padding.top;
    print(statusBarHeight);
    // print(MediaQueryData.fromWindow(window).padding.top);

    // int once = 1;

    return MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: Scaffold(
          // appBar: AppBar(
          //   title: const Text('hello world!'),
          // ),
          body: WebView(
              javascriptMode: JavascriptMode.unrestricted,
              zoomEnabled: false,
              /* javascriptChannels: {
              JavascriptChannel(
                  name: "toast",
                  onMessageReceived: (message) {
                    String result = message.message;
                    print(result);
                  })
            }, */
              // initialUrl: "https://baidu.com",
              onWebViewCreated: (WebViewController webViewController) {
                _controller = webViewController;
                _loadHtmlFromAssets();
              },
              onPageFinished: (url) {
                /* if(once == 1) {
                  Map params = {"statusBarHeight": statusBarHeight};
                  _controller.runJavascript('flutterOnPageFinished(${convert.jsonEncode(params)})');
                }
                once++; */
                Map params = {"statusBarHeight": statusBarHeight};
                _controller.runJavascript('flutterOnPageFinished(${convert.jsonEncode(params)})');
              }),
        ));
  }

  _loadHtmlFromAssets() async {
    /* String fileText = await rootBundle.loadString('assets/www/index.html');
    _controller.loadUrl( Uri.dataFromString(
        fileText,
        mimeType: 'text/html',
        encoding: Encoding.getByName('utf-8')
    ).toString()); */

    await _controller.loadFlutterAsset('assets/www/index.html');

    // await _controller.runJavascript('flutterCallJsMethodNoResult(123)');
  }
}
